extern float *statgeom(char **seqs, int n_of_seqs);
extern float *statgeom4(char **ss[4], int nn[4]);
extern void   printf_stg(float *B);
extern void SimplifiedBox(float *B, char *filename);

