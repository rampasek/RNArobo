#ifndef MEA_H
#define MEA_H

extern float MEA(plist *p, char *structure, double gamma);

#endif
