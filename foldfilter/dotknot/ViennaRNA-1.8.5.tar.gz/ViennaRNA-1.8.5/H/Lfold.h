#ifndef LFOLD_H
#define LFOLD_H

extern float  Lfold(char *string, char *structure, int maxdist);

#endif
